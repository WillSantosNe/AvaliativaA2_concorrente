package cliente;

public class LogCliente {

}
