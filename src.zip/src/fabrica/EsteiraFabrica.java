package fabrica;

import carro.Carro;
import carro.EsteiraCarro;

public class EsteiraFabrica {
	private final EsteiraCarro esteira;
	private volatile boolean producaoEncerrada = false;

    public EsteiraFabrica(int capacidade) {
        this.esteira = new EsteiraCarro(capacidade);
    }

    public int adicionarCarro(Carro carro) {
//    	System.out.println("ADD FABRICA");
        int posicao = esteira.adicionar(carro);
        carro.setPosicaoEsteiraFabrica(posicao);
        return posicao;
    }

    public Carro retirarCarro(boolean producaoEncerrada) {
        return esteira.retirar(producaoEncerrada);
    }


    public boolean estaVazia() {
        return esteira.estaVazia();
    }
    
    public void encerrarProducao() {
        producaoEncerrada = true;
        esteira.encerrar(); // <--- notifica o buffer da esteira
    }

    public boolean isProducaoEncerrada() {
        return producaoEncerrada;
    }
    
    

    public int getTotal() {
        return esteira.getTotal();
    }
}
