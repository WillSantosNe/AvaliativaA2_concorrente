package carro;

public class EsteiraCarro {
	private final Carro[] buffer;
	private int inicio = 0, fim = 0, total = 0;
	private volatile boolean encerrado = false;

	public EsteiraCarro(int capacidade) {
		buffer = new Carro[capacidade];
	}

	public synchronized int adicionar(Carro carro) {
		while (total == buffer.length) {
			try {
				System.out.println("TRAVOU ESTEIRA");
				wait(); // espera espaço
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}

		buffer[fim] = carro;
		int posicao = fim;
		fim = (fim + 1) % buffer.length;
		total++;
		notifyAll(); // avisa consumidores

		return posicao;
	}
	
	public synchronized int adicionar(Carro carro, boolean lojaAtiva) {
	    while (total == buffer.length) {
	        if (!lojaAtiva) return -1;
	        try {
	            wait();
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	            return -1;
	        }
	    }

	    buffer[fim] = carro;
	    int posicao = fim;
	    fim = (fim + 1) % buffer.length;
	    total++;
	    notifyAll();
	    return posicao;
	}


	public synchronized Carro retirar(boolean producaoEncerrada) {
	    while (total == 0) {
	        if (producaoEncerrada) return null;
	        try {
	            wait();
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	            return null;
	        }
	    }

	    Carro carro = buffer[inicio];
	    buffer[inicio] = null;
	    inicio = (inicio + 1) % buffer.length;
	    total--;
	    notifyAll();
	    return carro;
	}

	// Método antigo permanece igual para a EsteiraLoja
	public synchronized Carro retirar() {
		while (total == 0) {
			if (encerrado)
				return null;

			try {
				wait();
			} catch (InterruptedException e) {
				return null;
			}
		}

		Carro carro = buffer[inicio];
		buffer[inicio] = null;
		inicio = (inicio + 1) % buffer.length;
		total--;
		notifyAll();
		return carro;
	}

	public synchronized void encerrar() {
	    encerrado = true;
	    notifyAll(); // acorda qualquer thread travada no wait
	}

	public synchronized boolean estaVazia() {
		return total == 0;
	}

	public synchronized int getTotal() {
		return total;
	}
}
